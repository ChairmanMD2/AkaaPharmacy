(function(){
  function qs(s){return document.querySelector(s)}
  function showPage(name){
    $$('.pq-bottom-link').removeClass('tab-link-active');
    var a=document.querySelector('.pq-bottom-link[data-page="'+name+'"]');
    if(a) a.classList.add('tab-link-active');
  }
  window.pqSetPaymentPanels=function(method){
    document.querySelectorAll('.pq-pay-panel').forEach(function(e){e.classList.remove('active')});
    var p=qs('#pay-'+method); if(p)p.classList.add('active');
  };
  function isTextInput(t){
    if(!t) return false;
    var tag=(t.tagName||'').toLowerCase();
    return tag==='input' || tag==='textarea' || tag==='select' || t.isContentEditable;
  }
  document.addEventListener('input',function(e){
    var t=e.target;
    if(t && t.id==='pq-search') f7Func('search',t.value);
  },true);
  document.addEventListener('change',function(e){
    var t=e.target;
    if(t && t.id==='pq-category') f7Func('category',t.value);
    if(t && t.id==='pq-sort') f7Func('sort',t.value);
    if(t && t.name==='paymentMethod') pqSetPaymentPanels(t.value);
    if(t && t.id==='pq-rx-input' && t.files && t.files[0]) f7Func('rxFile',t.files[0].name);
  },true);
  $$(document).on('input:clear','#pq-search',function(){
    f7Func('search','');
  });
  document.addEventListener('focusin',function(e){
    var t=e.target;
    if(!isTextInput(t)) return;
    t.classList.add('pq-focused');
  },true);
  document.addEventListener('focusout',function(e){
    var t=e.target;
    if(t && t.classList) t.classList.remove('pq-focused');
  },true);
  document.addEventListener('pointerdown',function(e){
    var s=document.getElementById('pq-search');
    if(!s || document.activeElement!==s) return;
    var shell=e.target && e.target.closest ? e.target.closest('.pq-search-shell') : null;
    if(!shell) s.blur();
  },true);
  $$(document).on('page:afterin','.page',function(e){
    var name=this.getAttribute('data-name')||'';
    var id='';
    try{var r=e&&e.detail&&e.detail.route;if(r&&r.params)id=r.params.id||'';}catch(_){ }
    f7Func('page',JSON.stringify({name:name,id:id}));
    if(name==='home'){
      var s=document.getElementById('pq-search');
      if(s) s.setAttribute('autocomplete','off');
    }
    if(name==='tracking') setTimeout(function(){window.pqMapReset&&pqMapReset();},50);
  });

  var mapState={scale:1,x:0,y:0,drag:false,startX:0,startY:0,baseX:0,baseY:0,lastTouches:0,lastDistance:0,playing:false,timer:0,step:0};
  var mapPoints=[[12,72],[28,61],[43,67],[55,47],[67,40],[77,27],[89,17]];
  function stage(){return document.querySelector('.pq-map .pq-map-canvas')}
  function applyMap(){
    var el=stage(); if(!el)return;
    el.style.transform='translate3d('+mapState.x+'px,'+mapState.y+'px,0) scale('+mapState.scale+')';
  }
  function clampMap(){
    mapState.scale=Math.max(.85,Math.min(2.35,mapState.scale));
    var m=120*mapState.scale;
    mapState.x=Math.max(-m,Math.min(m,mapState.x));
    mapState.y=Math.max(-m,Math.min(m,mapState.y));
  }
  window.pqMapRecenter=function(){
    mapState.scale=1;mapState.x=0;mapState.y=0;applyMap();
  };
  window.pqMapReset=function(){
    mapState.scale=1;mapState.x=0;mapState.y=0;mapState.playing=false;
    if(mapState.timer) cancelAnimationFrame(mapState.timer);
    mapState.timer=0;
    var map=qs('.pq-map');
    mapState.step=map?Number(map.getAttribute('data-map-step')||0):0;
    applyMap();
    var point=mapPoints[Math.min(6,Math.max(0,mapState.step))];
    var b=qs('.pq-map-driver');
    if(b){b.style.left=point[0]+'%';b.style.top=point[1]+'%';}
    var p=qs('[data-map-action="play"] i'); if(p)p.textContent='play_fill';
  };
  window.pqMapControl=function(action){
    if(action==='zoom-in') mapState.scale+=.18;
    if(action==='zoom-out') mapState.scale-=.18;
    if(action==='recenter') {mapState.scale=1;mapState.x=0;mapState.y=0;}
    if(action==='play'){
      mapState.playing=!mapState.playing;
      var i=qs('[data-map-action="play"] i');
      if(i)i.textContent=mapState.playing?'pause_fill':'play_fill';
      if(mapState.playing) animateDriver();
    }
    clampMap();applyMap();
  };
  function animateDriver(){
    if(!mapState.playing) return;
    mapState.step=(mapState.step+0.02);
    var seg=Math.min(5,Math.floor(mapState.step));
    var frac=mapState.step-seg;
    var a=mapPoints[seg],b=mapPoints[seg+1]||a;
    var d=qs('.pq-map-driver');
    if(d){
      d.style.left=(a[0]+(b[0]-a[0])*frac)+'%';
      d.style.top=(a[1]+(b[1]-a[1])*frac)+'%';
      var lab=d.querySelector('.pq-driver-label');
      if(lab)lab.textContent='Demo delivery';
    }
    if(mapState.step>=6){mapState.step=0;mapState.playing=false;var i=qs('[data-map-action="play"] i');if(i)i.textContent='play_fill';return;}
    mapState.timer=requestAnimationFrame(animateDriver);
  }
  document.addEventListener('click',function(e){
    var b=e.target.closest&&e.target.closest('[data-map-action]');
    if(!b)return;
    e.preventDefault();
    pqMapControl(b.getAttribute('data-map-action'));
  },true);
  document.addEventListener('touchstart',function(e){
    var m=e.target.closest&&e.target.closest('.pq-map');
    if(!m || e.target.closest('[data-map-action]'))return;
    if(e.touches.length===1){
      mapState.drag=true;mapState.startX=e.touches[0].clientX;mapState.startY=e.touches[0].clientY;mapState.baseX=mapState.x;mapState.baseY=mapState.y;
    }else if(e.touches.length===2){
      mapState.drag=false;mapState.lastDistance=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);mapState.lastTouches=2;
    }
  },{passive:true});
  document.addEventListener('touchmove',function(e){
    var m=e.target.closest&&e.target.closest('.pq-map');
    if(!m)return;
    if(e.touches.length===1 && mapState.drag){
      mapState.x=mapState.baseX+(e.touches[0].clientX-mapState.startX);mapState.y=mapState.baseY+(e.touches[0].clientY-mapState.startY);clampMap();applyMap();
    }else if(e.touches.length===2){
      var d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);
      if(mapState.lastDistance>0){mapState.scale*=d/mapState.lastDistance;clampMap();applyMap();}
      mapState.lastDistance=d;
    }
  },{passive:true});
  document.addEventListener('touchend',function(e){
    if(!e.touches.length) mapState.drag=false;
    if(e.touches.length<2) mapState.lastDistance=0;
  },{passive:true});
  document.addEventListener('mousedown',function(e){
    var m=e.target.closest&&e.target.closest('.pq-map');
    if(!m || e.target.closest('[data-map-action]'))return;
    mapState.drag=true;mapState.startX=e.clientX;mapState.startY=e.clientY;mapState.baseX=mapState.x;mapState.baseY=mapState.y;
  });
  document.addEventListener('mousemove',function(e){
    if(!mapState.drag)return;
    mapState.x=mapState.baseX+(e.clientX-mapState.startX);mapState.y=mapState.baseY+(e.clientY-mapState.startY);clampMap();applyMap();
  });
  document.addEventListener('mouseup',function(){mapState.drag=false;});
})();
