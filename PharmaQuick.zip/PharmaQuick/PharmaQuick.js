
if (typeof cfg !== "undefined") cfg.EdgeToEdge = false;
app.LoadPlugin("F7Wrapper");

const STORE = "pharmaquick_poc_v3";
const ADMIN_PIN = "1234";

const ROLE = {
    customer: "Customer",
    system_admin: "System Administrator",
    cash_verification: "Cashier / Payment Verification Officer",
    clinical_verification: "Pharmacist / Clinical Verification Officer",
    inventory_control: "Inventory Control Officer",
    fulfillment_dispensing: "Fulfillment & Dispensing Officer",
    dispatch_delivery: "Dispatch & Delivery Officer"
};

const DEPT = {
    customer: "Customer Service",
    system_admin: "Administration",
    cash_verification: "Finance & Payment Verification",
    clinical_verification: "Clinical Verification",
    inventory_control: "Inventory Control",
    fulfillment_dispensing: "Fulfillment & Dispensing",
    dispatch_delivery: "Dispatch & Delivery"
};

class App {
    constructor() {
        this.quit = 0;
        this.adminUnlocked = false;
        this.searchTerm = "";
        this.category = "All";
        this.sort = "featured";
        this.currentUserId = "u-customer";
        this.cart = [];
        this.orders = [];
        this.prescriptions = [];
        this.favorites = [];
        this.recent = [];
        this.ledger = [];
        this.auditRuns = [];
        this.rxFileName = "";
        this.settings = { theme: "dark", notifications: true, compact: false };
        this.sequence = 1000;
        this.inventory = [
            { id: 1, sku: "PQ-PARA-500", name: "Paracetamol 500mg", category: "Pain & Fever", price: 450, openingStock: 50, stock: 50, reserved: 0, requiresRx: false, details: "Analgesic and antipyretic for pain and fever relief." },
            { id: 2, sku: "PQ-IBU-400", name: "Ibuprofen 400mg", category: "Pain & Fever", price: 620, openingStock: 32, stock: 32, reserved: 0, requiresRx: false, details: "NSAID for pain, inflammation and fever relief." },
            { id: 3, sku: "PQ-VITC-1000", name: "Vitamin C 1000mg", category: "Vitamins", price: 1200, openingStock: 15, stock: 15, reserved: 0, requiresRx: false, details: "Vitamin C supplement in a high-strength tablet." },
            { id: 4, sku: "PQ-ORS-001", name: "Oral Rehydration Salts", category: "First Aid", price: 300, openingStock: 80, stock: 80, reserved: 0, requiresRx: false, details: "Oral rehydration salts for replacement of fluid and electrolytes." },
            { id: 5, sku: "PQ-ANT-200", name: "Antacid Suspension", category: "Digestive Health", price: 950, openingStock: 24, stock: 24, reserved: 0, requiresRx: false, details: "For symptomatic relief of heartburn and indigestion." },
            { id: 6, sku: "PQ-MULTI-001", name: "Multivitamin Tablets", category: "Vitamins", price: 1800, openingStock: 18, stock: 18, reserved: 0, requiresRx: false, details: "Vitamin and mineral supplement for daily use." },
            { id: 7, sku: "PQ-CET-010", name: "Cetirizine 10mg", category: "Allergy", price: 700, openingStock: 28, stock: 28, reserved: 0, requiresRx: false, details: "Antihistamine for relief of common allergy symptoms." },
            { id: 8, sku: "PQ-AMOX-500", name: "Amoxicillin 500mg", category: "Antibiotics", price: 2600, openingStock: 20, stock: 20, reserved: 0, requiresRx: true, details: "Prescription antimicrobial. Dispensing requires clinical verification." },
            { id: 9, sku: "PQ-OME-020", name: "Omeprazole 20mg", category: "Digestive Health", price: 1400, openingStock: 26, stock: 26, reserved: 0, requiresRx: false, details: "Digestive-health product for the demonstration catalogue." },
            { id: 10, sku: "PQ-ZINC-020", name: "Zinc 20mg", category: "Vitamins", price: 900, openingStock: 30, stock: 30, reserved: 0, requiresRx: false, details: "Zinc supplement included in the POC pharmacy catalogue." },
            { id: 11, sku: "PQ-SALB-001", name: "Salbutamol Inhaler", category: "Respiratory", price: 3200, openingStock: 12, stock: 12, reserved: 0, requiresRx: true, details: "Prescription respiratory product. Dispensing requires clinical verification." },
            { id: 12, sku: "PQ-COUGH-001", name: "Cough Relief Syrup", category: "Cough & Cold", price: 1100, openingStock: 22, stock: 22, reserved: 0, requiresRx: false, details: "Cough and cold product in the demonstration catalogue." },
            { id: 13, sku: "PQ-CHX-001", name: "Chlorhexidine Antiseptic", category: "First Aid", price: 850, openingStock: 35, stock: 35, reserved: 0, requiresRx: false, details: "Topical antiseptic product for the POC inventory." },
            { id: 14, sku: "PQ-CLOT-001", name: "Clotrimazole Cream 1%", category: "Skin Care", price: 1200, openingStock: 18, stock: 18, reserved: 0, requiresRx: false, details: "Topical skin-care product in the demonstration catalogue." },
            { id: 15, sku: "PQ-PEDZ-001", name: "Oral Zinc Syrup", category: "Pediatrics", price: 950, openingStock: 16, stock: 16, reserved: 0, requiresRx: false, details: "Paediatric-category product included for workflow demonstration." },
            { id: 16, sku: "PQ-AL-020", name: "Artemether-Lumefantrine 20/120mg", category: "Antimalarials", price: 2400, openingStock: 20, stock: 20, reserved: 0, requiresRx: true, details: "Prescription antimalarial product. Dispensing requires clinical verification." },
            { id: 17, sku: "PQ-FOL-001", name: "Iron & Folic Acid Tablets", category: "Women's Health", price: 1600, openingStock: 25, stock: 25, reserved: 0, requiresRx: false, details: "Women's-health category supplement for the POC catalogue." },
            { id: 18, sku: "PQ-NS-500", name: "Normal Saline 500ml", category: "First Aid", price: 750, openingStock: 40, stock: 40, reserved: 0, requiresRx: true, details: "Clinical-use product marked prescription-required for this demo." },
            { id: 19, sku: "PQ-LOP-002", name: "Loperamide 2mg", category: "Digestive Health", price: 500, openingStock: 14, stock: 14, reserved: 0, requiresRx: false, details: "Digestive-health product included in the demo catalogue." },
            { id: 20, sku: "PQ-SAN-500", name: "Hand Sanitizer 500ml", category: "First Aid", price: 1300, openingStock: 27, stock: 27, reserved: 0, requiresRx: false, details: "Hygiene product included in the demonstration inventory." }
        ];
        this.users = [
            { id: "u-customer", name: "Demo Customer", email: "customer@pharmaquick.demo", phone: "08000000001", password: "1234", role: "customer", active: true },
            { id: "u-cashier", name: "Demo Cashier", email: "cashier@pharmaquick.demo", phone: "08000000002", password: "1234", role: "cash_verification", active: true },
            { id: "u-pharmacist", name: "Demo Pharmacist", email: "pharmacist@pharmaquick.demo", phone: "08000000003", password: "1234", role: "clinical_verification", active: true },
            { id: "u-inventory", name: "Demo Inventory Officer", email: "inventory@pharmaquick.demo", phone: "08000000004", password: "1234", role: "inventory_control", active: true },
            { id: "u-fulfillment", name: "Demo Dispensing Officer", email: "fulfillment@pharmaquick.demo", phone: "08000000005", password: "1234", role: "fulfillment_dispensing", active: true },
            { id: "u-dispatch", name: "Demo Delivery Officer", email: "dispatch@pharmaquick.demo", phone: "08000000006", password: "1234", role: "dispatch_delivery", active: true },
            { id: "u-admin", name: "Demo Administrator", email: "admin@pharmaquick.demo", phone: "08000000007", password: "1234", role: "system_admin", active: true }
        ];
        this.loadState();
        this.seedOpeningLedger();
    }

    onInit() {
        app.EnableBackKey = true;
        this.clr = this.settings.theme === "light" ? "#f5f8f7" : "#0f1817";
        try { if (app.SetStatusBarColor) app.SetStatusBarColor(this.clr); } catch (e) {}
        try { if (app.SetNavBarColor) app.SetNavBarColor(this.clr); } catch (e) {}
        f7.setOptions("usebasicinput");
        f7.setBackColor(this.clr);
        f7.disableDrag();
        f7.disableTextSelection();
    }

    onStart() {
        f7.delayResize(15);
        f7.setTouchOptions({ tapHold: true, mdTouchRipple: true });
        f7.setPanelOptions({ swipe: false });
        f7.setDialogOptions({ closeByBackdropClick: true });
        f7.setColorTheme("#00bfa5");
        f7.style("Html/css/style.css");
        f7.script("Html/js/main.js", false);
        f7.addPanel("Html/panel.html");

        f7.onReady(() => {
            this.applySettings();
            setTimeout(() => {
                f7.navigate("/home", { animate: false });
                this.saveState();
            }, 120);
        });

        f7.addPage("Html/splash.html", { path: "/" }, true);
        f7.addPage("Html/home.html", { path: "/home" });
        f7.addPage("Html/auth.html", { path: "/auth" });
        f7.addPage("Html/product.html", { path: "/product/:id/" });
        f7.addPage("Html/rx.html", { path: "/rx" });
        f7.addPage("Html/cart.html", { path: "/cart" });
        f7.addPage("Html/checkout.html", { path: "/checkout" });
        f7.addPage("Html/orders.html", { path: "/orders" });
        f7.addPage("Html/tracking.html", { path: "/tracking/:id/" });
        f7.addPage("Html/favorites.html", { path: "/favorites" });
        f7.addPage("Html/settings.html", { path: "/settings" });
        f7.addPage("Html/account.html", { path: "/account" });
        f7.addPage("Html/admin.html", { path: "/admin" });
        f7.addPage("Html/audit.html", { path: "/audit" });
        f7.addPage("Html/about.html", { path: "/about" });

    }

    onBack(path) {
        path = String(path || "/");
        if (path === "/" || path === "/home") {
            f7.execute(`(function(){
                var s=document.getElementById('pq-search');
                return JSON.stringify({active:!!(s&&document.activeElement===s),value:s?s.value:''});
            })()`, result => {
                let state={active:false,value:""};
                try { state=JSON.parse(result||"{}"); } catch(e) {}
                if (state.active || String(state.value||"").length) {
                    this.searchTerm="";
                    f7.execute(`(function(){
                        var s=document.getElementById('pq-search');
                        if(s){s.value='';s.classList.remove('input-with-value');s.blur();}
                        if(document.activeElement&&document.activeElement.blur)document.activeElement.blur();
                    })();`);
                    this.renderProducts();
                    return;
                }
                f7.execute("(function(){var e=document.querySelector('.view-main .page-current .page-content');return e?e.scrollTop:0;})()", scroll => {
                    if (Number(scroll || 0) > 8) {
                        f7.execute("(function(){var e=document.querySelector('.view-main .page-current .page-content');if(e)e.scrollTo({top:0,behavior:'smooth'});})();");
                        f7.delayResize(12);
                    } else {
                        this.confirmExit();
                    }
                });
            });
        } else {
            f7.back();
        }
    }

    onPause() {}
    onResume() {}
    onConfig() {}
    onData() {}

    onFunc(key, value) {
        try {
            key = String(key || "");
            value = value == null ? "" : String(value);
            switch (key) {
                case "page": this.handlePage(value); break;
                case "search": this.searchTerm = value; this.renderProducts(); break;
                case "clearSearch": this.searchTerm = ""; this.renderProducts(); this.exec(`var e=document.getElementById("pq-search");if(e){e.value="";e.focus();}`); break;
                case "category": this.category = value || "All"; this.renderProducts(); break;
                case "sort": this.sort = value || "featured"; this.renderProducts(); break;
                case "openProduct": this.openProduct(parseInt(value, 10)); break;
                case "showProduct": this.renderProductDetail(this.findProduct(parseInt(value, 10))); break;
                case "add": this.addToCart(parseInt(value, 10)); break;
                case "plus": this.changeQty(parseInt(value, 10), 1); break;
                case "minus": this.changeQty(parseInt(value, 10), -1); break;
                case "remove": this.removeFromCart(parseInt(value, 10)); break;
                case "favorite": this.toggleFavorite(parseInt(value, 10)); break;
                case "checkout": this.startCheckout(); break;
                case "createOrder": this.createOrder(value); break;
                case "rxFile": this.rxFileName = value; this.renderRx(); this.saveState(); break;
                case "submitRx": this.submitPrescription(); break;
                case "removeRx": this.rxFileName = ""; this.renderRx(); this.saveState(); break;
                case "track": this.openTracking(value); break;
                case "adminPin": this.adminPin(value); break;
                case "logout": this.logout(); break;
                case "login": this.login(value); break;
                case "demoLogin": this.demoLogin(value); break;
                case "signup": this.signup(value); break;
                case "setting": this.setSetting(value); break;
                case "reset": this.confirmResetData(); break;
                case "support": this.support(); break;
                case "exit": this.confirmExit(); break;
                case "clearCart": this.confirmClearCart(); break;
                case "verifyPayment": this.verifyPayment(value, true); break;
                case "rejectPayment": this.verifyPayment(value, false); break;
                case "verifyRx": this.verifyRx(value); break;
                case "allocate": this.allocateStock(value); break;
                case "dispense": this.dispenseOrder(value); break;
                case "dispatch": this.dispatchOrder(value); break;
                case "deliver": this.deliverOrder(value); break;
                case "cancelOrder": this.cancelOrder(value); break;
                case "restock": this.restock(value); break;
                case "assignRole": this.assignRole(value); break;
                case "toggleUser": this.toggleUser(value); break;
                case "audit": this.runAudit(true); break;
                case "map": this.handleMap(value); break;
            }
        } catch (e) {
            try { f7.alert(e && e.message ? e.message : String(e), "PharmaQuick"); } catch (_) {}
        }
    }

    handlePage(value) {
        let page = value;
        let id = "";
        try {
            const obj = JSON.parse(value);
            page = obj.name;
            id = obj.id || "";
        } catch (e) {}
        switch (page) {
            case "home": this.renderProducts(); break;
            case "auth": this.renderAuth(); break;
            case "product": this.renderProductDetail(this.findProduct(parseInt(id, 10))); break;
            case "rx": this.renderRx(); break;
            case "cart": this.renderCart(); break;
            case "checkout": this.renderCheckout(); break;
            case "orders": this.renderOrders(); break;
            case "tracking": this.renderTracking(this.findOrder(id)); break;
            case "favorites": this.renderFavorites(); break;
            case "settings": this.renderSettings(); break;
            case "account": this.renderAccount(); break;
            case "admin": this.renderAdmin(); break;
            case "audit": this.renderAudit(); break;
        }
        this.updateBadges();
        this.setActiveTab(page);
    }
    loadState() {
        try {
            const raw = app.LoadText(STORE, "", "fileMN");
            if (!raw) return;
            const s = JSON.parse(raw);
            if (Array.isArray(s.users) && s.users.length) this.users = s.users;
            if (Array.isArray(s.cart)) this.cart = s.cart;
            if (Array.isArray(s.orders)) this.orders = s.orders;
            if (Array.isArray(s.prescriptions)) this.prescriptions = s.prescriptions;
            if (Array.isArray(s.favorites)) this.favorites = s.favorites.map(Number);
            if (Array.isArray(s.recent)) this.recent = s.recent.map(Number);
            if (Array.isArray(s.ledger)) this.ledger = s.ledger;
            if (Array.isArray(s.auditRuns)) this.auditRuns = s.auditRuns;
            if (s.inventory && Array.isArray(s.inventory)) {
                s.inventory.forEach(saved => {
                    const p = this.findProduct(saved.id);
                    if (p) Object.assign(p, saved);
                });
            }
            if (s.settings) this.settings = Object.assign(this.settings, s.settings);
            this.currentUserId = s.currentUserId || this.currentUserId;
            this.sequence = Number(s.sequence || this.sequence);
        } catch (e) {
            this.cart = [];
            this.orders = [];
            this.prescriptions = [];
            this.favorites = [];
            this.recent = [];
            this.ledger = [];
            this.auditRuns = [];
        }
    }

    saveState() {
        try {
            app.SaveText(STORE, JSON.stringify({
                users: this.users,
                cart: this.cart,
                orders: this.orders,
                prescriptions: this.prescriptions,
                favorites: this.favorites,
                recent: this.recent,
                inventory: this.inventory,
                ledger: this.ledger,
                auditRuns: this.auditRuns.slice(-20),
                settings: this.settings,
                currentUserId: this.currentUserId,
                sequence: this.sequence
            }), "fileMN");
        } catch (e) {}
    }

    seedOpeningLedger() {
        let changed = false;
        this.inventory.forEach(p => {
            const hasOpening = this.ledger.some(m => Number(m.productId) === Number(p.id) && m.type === "OPENING");
            if (!hasOpening) {
                this.ledger.push({ type: "OPENING", productId: p.id, qty: p.openingStock, unitPrice: p.price, orderId: "", actor: "System", role: ROLE.system_admin, at: new Date().toISOString(), note: "Opening stock" });
                changed = true;
            }
        });
        if (changed) this.saveState();
    }
    user() { return this.users.find(u => u.id === this.currentUserId) || this.users[0]; }
    role() { return this.user().role; }
    esc(v) { return String(v == null ? "" : v).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c])); }
    money(n) { return "₦" + Number(n || 0).toLocaleString("en-NG"); }
    dateTime(v) { try { return new Date(v).toLocaleString("en-NG", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }); } catch (e) { return String(v); } }
    html(sel, value) {
        const selector = JSON.stringify(String(sel));
        const markup = JSON.stringify(String(value == null ? "" : value));
        this.exec(`(function(){var e=document.querySelector(${selector});if(e)e.innerHTML=${markup};})();`);
    }
    currentHtml(id, value) {
        const safeId = String(id).replace(/[^a-zA-Z0-9_-]/g, "");
        this.exec(`(function(){var e=document.querySelector('.view-main .page-current #${safeId}');if(e)e.innerHTML=${JSON.stringify(value)};})();`);
    }
    findProduct(id) { return this.inventory.find(p => Number(p.id) === Number(id)); }
    findOrder(id) { return this.orders.find(o => String(o.id) === String(id)); }
    available(p) { return Math.max(0, Number(p.stock || 0) - Number(p.reserved || 0)); }
    currentUserName() { return this.user().name; }
    hasRole(...roles) { return roles.includes(this.role()); }
    can(action) {
        const map = {
            payment: ["system_admin", "cash_verification"],
            clinical: ["system_admin", "clinical_verification"],
            allocate: ["system_admin", "inventory_control"],
            dispense: ["system_admin", "fulfillment_dispensing"],
            dispatch: ["system_admin", "dispatch_delivery"]
        };
        return (map[action] || []).includes(this.role());
    }
    event(order, status, detail, roleOverride) {
        order.events = order.events || [];
        order.events.push({ status, detail, actor: this.currentUserName(), role: ROLE[roleOverride || this.role()] || ROLE[this.role()] || this.role(), department: DEPT[roleOverride || this.role()] || DEPT[this.role()] || "Operations", at: new Date().toISOString() });
        order.updatedAt = new Date().toISOString();
    }
    ledgerMove(type, productId, qty, unitPrice, orderId, note) {
        this.ledger.push({ type, productId: Number(productId), qty: Number(qty), unitPrice: Number(unitPrice), orderId: orderId || "", actor: this.currentUserName(), role: ROLE[this.role()] || this.role(), at: new Date().toISOString(), note: note || "" });
    }
    cartTotals() {
        let subtotal = 0;
        this.cart.forEach(it => subtotal += Number(it.qty) * Number(it.unitPrice));
        const delivery = subtotal > 0 ? 500 : 0;
        return { subtotal, delivery, total: subtotal + delivery };
    }
    orderRequiresRx(items) { return items.some(it => { const p = this.findProduct(it.productId); return p && p.requiresRx; }); }
    userOrders() { const u = this.user(); return this.orders.filter(o => o.customerId === u.id); }
    latestSubmittedRx() { return this.prescriptions.slice().reverse().find(r => r.customerId === this.user().id && r.status !== "Rejected"); }
    applySettings() {
        const light = this.settings.theme === "light";
        this.clr = light ? "#f5f8f7" : "#0f1817";
        try { f7.enableDarkMode(!light); } catch (e) {}
        try { f7.setBackColor(this.clr); } catch (e) {}
        try { if (app.SetStatusBarColor) app.SetStatusBarColor(this.clr); } catch (e) {}
        try { if (app.SetNavBarColor) app.SetNavBarColor(this.clr); } catch (e) {}
        this.exec(`document.documentElement.classList.toggle("pq-light", ${light}); document.body.classList.toggle("pq-light", ${light}); document.documentElement.classList.toggle("pq-compact", ${!!this.settings.compact});`);
    }
    exec(code) { f7.execute(code); }
    setActiveTab(page) {
        const target = page === "tracking" || page === "product" || page === "checkout" ? "orders" : page;
        this.exec(`$$('.pq-bottom-link').removeClass('tab-link-active'); var e=document.querySelector('.pq-bottom-link[data-page="${this.esc(target)}"]'); if(e) e.classList.add('tab-link-active');`);
    }
    updateBadges() {
        const cartCount = this.cart.reduce((s, it) => s + Number(it.qty || 0), 0);
        const favCount = this.favorites.length;
        this.exec(`document.querySelectorAll('.pq-cart-count').forEach(function(e){e.textContent=${cartCount}; e.style.display=${JSON.stringify(cartCount ? 'inline-flex' : 'none')};}); document.querySelectorAll('.pq-fav-count').forEach(function(e){e.textContent=${favCount}; e.style.display=${JSON.stringify(favCount ? 'inline-flex' : 'none')};});`);
    }
    go(path) { f7.navigate(path); }
    renderProducts() {
        const search = this.searchTerm.toLowerCase().trim();
        const terms = search.split(/\s+/).filter(Boolean);
        let list = this.inventory.filter(p => {
            const searchable = (p.name + " " + p.category + " " + p.sku + " " + (p.details || "")).toLowerCase();
            const matchText = !terms.length || terms.every(term => searchable.includes(term));
            const matchCat = this.category === "All" || p.category === this.category;
            return matchText && matchCat;
        });
        if (this.sort === "name") list.sort((a,b) => a.name.localeCompare(b.name));
        if (this.sort === "priceLow") list.sort((a,b) => a.price - b.price);
        if (this.sort === "priceHigh") list.sort((a,b) => b.price - a.price);
        if (this.sort === "stock") list.sort((a,b) => this.available(a) - this.available(b));
        const favs = this.favorites;
        this.html("#pq-products", list.length ? list.map(p => {
            const av = this.available(p);
            const fav = favs.includes(p.id);
            const low = av <= 10;
            return `<article class="pq-product-card ${this.settings.compact ? "is-compact" : ""}">
                <div class="pq-product-main" onclick="f7Func('openProduct','${p.id}')">
                    <div class="pq-product-icon">${p.requiresRx ? "Rx" : "OTC"}</div>
                    <div class="pq-product-info"><strong>${this.esc(p.name)}</strong><small>${this.esc(p.category)}${p.requiresRx ? " • Prescription required" : ""}</small><b>${this.money(p.price)}</b></div>
                    <div class="pq-product-actions"><button class="pq-icon-button ${fav ? "active" : ""}" onclick="event.stopPropagation();f7Func('favorite','${p.id}')"><i class="icon f7-icons">${fav ? "heart_fill" : "heart"}</i></button><i class="icon f7-icons pq-chevron">chevron_right</i></div>
                </div>
                <div class="pq-product-footer"><span class="${low ? "low" : ""}"><i></i>${av} in stock</span><button class="button button-fill pq-add" ${av < 1 ? "disabled" : ""} onclick="event.stopPropagation();f7Func('add','${p.id}')">${av < 1 ? "Out of stock" : "Add to cart"}</button></div>
            </article>`;
        }).join("") : `<div class="pq-empty"><i class="icon f7-icons">search</i><strong>No products found</strong><span>Try another search or category.</span></div>`);
        this.exec(`var s=document.getElementById('pq-search');if(s){s.value=${JSON.stringify(this.searchTerm)};s.classList.toggle('input-with-value',!!s.value);}`);
        this.exec(`var c=document.getElementById('pq-category'); if(c) c.value=${JSON.stringify(this.category)}; var so=document.getElementById('pq-sort'); if(so) so.value=${JSON.stringify(this.sort)};`);
        this.html("#pq-product-count", `${list.length} product${list.length === 1 ? "" : "s"}`);
        this.html("#pq-search-hint", search ? `Results for “${this.esc(this.searchTerm.trim())}”` : "Browse all available products");
        this.html("#pq-fav-label", String(this.favorites.length));
        this.html("#pq-home-user", this.esc(this.currentUserName()));
    }
    openProduct(id) {
        const p = this.findProduct(id);
        if (!p) return;
        if (!this.recent.includes(p.id)) this.recent.unshift(p.id);
        this.recent = this.recent.slice(0, 8);
        this.saveState();
        this.go(`/product/${p.id}/`);
    }
    renderProductDetail(p) {
        if (!p) { this.html("#pq-product-detail", `<div class="pq-empty"><strong>Product unavailable</strong></div>`); return; }
        const fav = this.favorites.includes(p.id);
        const av = this.available(p);
        this.html("#pq-product-detail", `<div class="pq-detail-card"><div class="pq-detail-icon">${p.requiresRx ? "Rx" : "OTC"}</div><div class="pq-detail-category">${this.esc(p.category)}</div><h1>${this.esc(p.name)}</h1><div class="pq-detail-sku">SKU ${this.esc(p.sku)}</div><div class="pq-detail-price">${this.money(p.price)}</div><p>${this.esc(p.details)}</p><div class="pq-detail-stock ${av <= 10 ? "low" : ""}"><span>Available: ${av}</span><span>•</span><span>${p.requiresRx ? "Prescription required" : "No prescription required"}</span></div><div class="pq-detail-actions"><button class="button button-outline" onclick="f7Func('favorite','${p.id}')"><i class="icon f7-icons">${fav ? "heart_fill" : "heart"}</i> ${fav ? "Saved" : "Favorite"}</button><button class="button button-fill" ${av < 1 ? "disabled" : ""} onclick="f7Func('add','${p.id}')">${av < 1 ? "Out of stock" : "Add to cart"}</button></div></div>`);
    }
    addToCart(id) {
        const p = this.findProduct(id);
        if (!p || this.available(p) < 1) { f7.toast("This item is out of stock", 1400); return; }
        const found = this.cart.find(x => x.productId === p.id);
        const qty = found ? found.qty + 1 : 1;
        if (qty > this.available(p)) { f7.toast("Quantity exceeds current availability", 1600); return; }
        if (found) found.qty = qty; else this.cart.push({ productId: p.id, sku: p.sku, name: p.name, qty: 1, unitPrice: p.price });
        this.saveState(); this.updateBadges(); this.renderCart();
        f7.toast(`${p.name} added to cart`, 1200);
    }
    changeQty(id, delta) {
        const it = this.cart.find(x => x.productId === id);
        const p = this.findProduct(id);
        if (!it || !p) return;
        const next = it.qty + delta;
        if (next < 1) return this.removeFromCart(id);
        if (next > this.available(p)) { f7.toast("Not enough stock", 1400); return; }
        it.qty = next; this.saveState(); this.renderCart(); this.updateBadges();
    }
    removeFromCart(id) { this.cart = this.cart.filter(x => x.productId !== id); this.saveState(); this.renderCart(); this.updateBadges(); }
    toggleFavorite(id) {
        if (this.favorites.includes(id)) this.favorites = this.favorites.filter(x => x !== id); else this.favorites.unshift(id);
        this.saveState(); this.updateBadges(); this.renderProducts(); this.renderFavorites(); this.renderProductDetail(this.findProduct(id));
        f7.toast(this.favorites.includes(id) ? "Added to favorites" : "Removed from favorites", 1100);
    }
    renderCart() {
        const listHtml = this.cart.length ? this.cart.map(it => `<div class="pq-cart-row"><div class="pq-mini-icon">${this.findProduct(it.productId)?.requiresRx ? "Rx" : "OTC"}</div><div class="pq-cart-name"><strong>${this.esc(it.name)}</strong><small>${this.esc(it.sku)} • ${this.money(it.unitPrice)} each</small></div><div class="pq-qty-box"><button onclick="f7Func('minus','${it.productId}')">−</button><b>${it.qty}</b><button onclick="f7Func('plus','${it.productId}')">+</button></div><button class="pq-delete" onclick="f7Func('remove','${it.productId}')"><i class="icon f7-icons">trash</i></button></div>`).join("") : `<div class="pq-empty"><i class="icon f7-icons">cart</i><strong>Your cart is empty</strong><span>Add products from the shop to begin checkout.</span><a href="/home" class="button button-fill">Browse products</a></div>`;
        this.exec(`(function(){
            var lists=document.querySelectorAll('#pq-cart-list');
            lists.forEach(function(e){e.innerHTML=${JSON.stringify(listHtml)};});
        })();`);
        if (!this.cart.length) {
            this.exec(`(function(){
                document.querySelectorAll('#pq-cart-summary').forEach(function(e){e.innerHTML='';e.style.display='none';});
            })();`);
            return;
        }
        const t = this.cartTotals();
        const rx = this.orderRequiresRx(this.cart);
        const summaryHtml = `<div class="pq-summary"><div class="pq-summary-row"><span>Items</span><b>${this.cart.reduce((s,i)=>s+i.qty,0)}</b></div><div class="pq-summary-row"><span>Products</span><b>${this.money(t.subtotal)}</b></div><div class="pq-summary-row"><span>Delivery</span><b>${this.money(t.delivery)}</b></div><div class="pq-summary-row total"><span>Total</span><b>${this.money(t.total)}</b></div>${rx ? `<div class="pq-rx-note"><i class="icon f7-icons">info_circle</i> Prescription-required item(s) need clinical verification.</div>` : ""}<button class="button button-fill pq-checkout-button" onclick="f7Func('checkout','1')">Proceed to checkout</button><button class="button button-outline pq-clear-button" onclick="f7Func('clearCart','1')">Clear cart</button></div>`;
        this.exec(`(function(){var e=document.querySelector('.view-main .page-current #pq-cart-summary');if(e){e.innerHTML=${JSON.stringify(summaryHtml)};e.style.display='';}})();`);
    }
    startCheckout() { if (!this.cart.length) { f7.toast("Your cart is empty", 1300); return; } this.go("/checkout"); }
    clearCheckoutForm() {
        this.exec(`(function(){document.querySelectorAll('[id^="co-"]').forEach(function(e){if(e.tagName==='INPUT'||e.tagName==='TEXTAREA')e.value='';});document.querySelectorAll('input[name="paymentMethod"]').forEach(function(e){e.checked=e.value==='card';});document.querySelectorAll('.pq-pay-panel').forEach(function(e){e.classList.remove('active');});var p=document.getElementById('pay-card');if(p)p.classList.add('active');var b=document.getElementById('pq-checkout-summary');if(b)b.dataset.rxId='';var i=document.getElementById('pq-checkout-items');if(i)i.innerHTML='';var t=document.getElementById('pq-checkout-total');if(t)t.textContent='₦0';var r=document.getElementById('pq-checkout-rx');if(r)r.innerHTML='';})();`);
    }
    confirmClearCart() { f7.confirm("Remove all items from the cart?", "Clear cart", () => { this.cart=[]; this.clearCheckoutForm(); this.saveState(); this.renderCart(); this.renderCheckout(); this.updateBadges(); f7.toast("Cart cleared",1100); }); }
    renderRx() {
        const latest = this.latestSubmittedRx();
        this.html("#pq-rx-file", this.rxFileName ? `<div class="pq-rx-selected"><div class="pq-mini-icon">Rx</div><div><strong>${this.esc(this.rxFileName)}</strong><small>Selected for submission</small></div><button class="button button-small button-outline" onclick="f7Func('removeRx','1')">Remove</button></div>` : `<div class="pq-rx-empty"><i class="icon f7-icons">camera</i><strong>No prescription selected</strong><span>Choose a prescription image below. This POC stores the file name as the demonstration record.</span></div>`);
        this.html("#pq-rx-history", this.prescriptions.filter(r => r.customerId === this.user().id).slice().reverse().map(r => `<div class="pq-record-row"><div><strong>${this.esc(r.id)}</strong><small>${this.esc(r.fileName)} • ${this.dateTime(r.createdAt)}</small></div><span class="pq-status ${r.status === "Rejected" ? "danger" : ""}">${this.esc(r.status)}</span></div>`).join("") || `<div class="pq-empty mini"><span>No prescription records yet.</span></div>`);
        if (latest) this.html("#pq-latest-rx", `<div class="pq-info-strip"><i class="icon f7-icons">checkmark_shield_fill</i><span>Latest prescription <b>${this.esc(latest.id)}</b> • ${this.esc(latest.status)}</span></div>`); else this.html("#pq-latest-rx", "");
    }
    submitPrescription() {
        if (!this.rxFileName) { f7.alert("Please select a prescription image first.", "Prescription"); return; }
        const id = "RX-" + (++this.sequence);
        this.prescriptions.push({ id, customerId: this.user().id, fileName: this.rxFileName, status: "Pending Clinical Verification", createdAt: new Date().toISOString(), verifiedAt: "" });
        const file = this.rxFileName;
        this.rxFileName = "";
        this.saveState(); this.renderRx();
        f7.toast(`${id} submitted for pharmacist review`, 1800);
        this.go("/orders");
    }
    renderCheckout() {
        const t = this.cartTotals();
        const rx = this.orderRequiresRx(this.cart);
        const latest = this.latestSubmittedRx();
        this.html("#pq-checkout-items", this.cart.map(i => `<div class="pq-summary-item"><span>${this.esc(i.name)} × ${i.qty}</span><b>${this.money(i.qty*i.unitPrice)}</b></div>`).join("") || `<span>No items</span>`);
        this.html("#pq-checkout-total", this.money(t.total));
        this.html("#pq-checkout-rx", rx ? `<div class="pq-warning"><i class="icon f7-icons">info_circle</i><div><strong>Clinical verification required</strong><small>${latest ? `Use ${this.esc(latest.id)} (${this.esc(latest.status)})` : "Submit a prescription before placing this order."}</small></div></div>` : `<div class="pq-success-strip"><i class="icon f7-icons">checkmark_circle_fill</i><span>No prescription-required item is in this cart.</span></div>`);
        this.exec(`var box=document.querySelector('#pq-checkout-summary'); if(box) box.dataset.rxId=${JSON.stringify(latest?latest.id:'')}; var p=document.querySelector('input[name="paymentMethod"]:checked'); var method=p?p.value:'card'; if(window.pqSetPaymentPanels) pqSetPaymentPanels(method);`);
    }
    createOrder(raw) {
        let data; try { data = JSON.parse(raw); } catch (e) { throw new Error("Checkout data could not be read."); }
        if (!this.cart.length) throw new Error("Your cart is empty.");
        const t = this.cartTotals();
        const requiredRx = this.orderRequiresRx(this.cart);
        if (requiredRx && !data.rxId) throw new Error("This order contains a prescription-required item. Submit a prescription first.");
        if (requiredRx) {
            const rx = this.prescriptions.find(r => r.id === data.rxId && r.customerId === this.user().id && r.status !== "Rejected");
            if (!rx) throw new Error("The selected prescription record is not valid.");
        }
        this.cart.forEach(it => {
            const p = this.findProduct(it.productId);
            if (!p || it.qty < 1 || it.qty > this.available(p)) throw new Error(`Insufficient availability for ${it.name}.`);
        });
        const method = String(data.paymentMethod || "card");
        if (!["card","transfer","cash"].includes(method)) throw new Error("Choose a valid payment method.");
        const payment = { method, amount: t.total, status: "Pending Verification", reference: "", maskedCard: "", cardHolder: "", tendered: 0, change: 0, verifiedAt: "", verifiedBy: "" };
        if (method === "card") {
            const digits = String(data.cardNumber || "").replace(/\D/g, "");
            const holder = String(data.cardHolder || "").trim();
            if (!holder) throw new Error("Enter the card holder name.");
            if (digits.length < 12) throw new Error("Enter a valid demo card number.");
            payment.cardHolder = holder;
            payment.maskedCard = "•••• " + digits.slice(-4); payment.reference = "CARD-DEMO-" + digits.slice(-4);
        } else if (method === "transfer") {
            const ref = String(data.transferReference || "").trim();
            if (ref.length < 4) throw new Error("Enter the demo bank transfer reference.");
            payment.reference = ref.toUpperCase();
        } else {
            const tendered = Number(data.cashTendered || 0);
            if (tendered < t.total) throw new Error("Cash tendered is less than the order total.");
            payment.tendered = tendered; payment.change = tendered - t.total; payment.reference = "CASH-" + (++this.sequence);
        }
        const items = this.cart.map(i => ({ productId: i.productId, sku: i.sku, name: i.name, qty: i.qty, unitPrice: i.unitPrice, lineTotal: i.qty * i.unitPrice }));
        const customer = { name: String(data.name || this.user().name).trim(), phone: String(data.phone || this.user().phone || "").trim(), address: String(data.address || "").trim() };
        if (!customer.name || !customer.phone || !customer.address) throw new Error("Name, phone and delivery address are required.");
        const id = "PQ-" + (++this.sequence);
        const rx = requiredRx ? this.prescriptions.find(r => r.id === data.rxId) : null;
        const order = {
            id,
            trackingCode: "TRK-" + id.slice(-6),
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            customerId: this.user().id,
            customer,
            items,
            productTotal: t.subtotal,
            deliveryFee: t.delivery,
            total: t.total,
            payment,
            rxId: rx ? rx.id : "",
            status: "Awaiting Payment Verification",
            reserved: false,
            issued: false,
            dispatched: false,
            delivered: false,
            driverId: "",
            signature: "",
            events: []
        };
        this.orders.push(order);
        this.event(order, order.status, `Order created. ${this.money(order.total)} awaiting payment verification.`);
        if (rx) this.event(order, order.status, `Prescription ${rx.id} attached for clinical verification.`);
        this.cart = [];
        this.clearCheckoutForm();
        this.saveState(); this.renderCart(); this.renderCheckout(); this.updateBadges();
        f7.alert(`Order ${id} has been created. Payment verification is the first control step.`, "Order received");
        this.go(`/tracking/${id}/`);
    }
    verifyPayment(raw, accepted) {
        if (!this.can("payment")) { f7.toast("Payment verification is restricted to the payment verification role.", 2200); return; }
        const o = this.findOrder(raw); if (!o) return;
        if (o.payment.status !== "Pending Verification") return;
        if (!accepted) {
            o.payment.status = "Rejected";
            o.status = "Payment Rejected / Order Cancelled";
            this.event(o, o.status, "Payment failed verification. Order closed without stock allocation.");
            this.saveState(); this.renderAdmin(); this.renderOrders(); this.renderTracking(o); return;
        }
        if (Number(o.payment.amount) !== Number(o.total)) throw new Error("Payment amount does not exactly match the order total.");
        o.payment.status = "Verified"; o.payment.verifiedAt = new Date().toISOString(); o.payment.verifiedBy = this.currentUserName();
        o.status = o.rxId ? "Clinical Verification Required" : "Awaiting Stock Allocation";
        this.event(o, o.status, `Payment verified for ${this.money(o.payment.amount)} by ${this.currentUserName()}.`);
        this.saveState(); this.renderAdmin(); this.renderOrders(); this.renderTracking(o); f7.toast("Payment verified",1300);
    }
    verifyRx(id) {
        if (!this.can("clinical")) { f7.toast("Clinical verification requires a pharmacist / clinical verification officer.", 2200); return; }
        const o = this.findOrder(id); if (!o || !o.rxId || o.status !== "Clinical Verification Required") return;
        const rx = this.prescriptions.find(r => r.id === o.rxId);
        if (rx) { rx.status = "Clinically Verified"; rx.verifiedAt = new Date().toISOString(); }
        o.status = "Awaiting Stock Allocation";
        this.event(o, o.status, `Prescription ${o.rxId} clinically verified. Order released to Inventory Control.`);
        this.saveState(); this.renderAdmin(); this.renderTracking(o); f7.toast("Clinical verification completed",1500);
    }
    allocateStock(id) {
        if (!this.can("allocate")) { f7.toast("Stock allocation requires Inventory Control Officer role.", 2200); return; }
        const o = this.findOrder(id); if (!o || o.status !== "Awaiting Stock Allocation") return;
        o.items.forEach(it => { const p=this.findProduct(it.productId); if(!p || this.available(p)<it.qty) throw new Error(`Insufficient stock for ${it.name}. Allocation aborted.`); });
        o.items.forEach(it => { const p=this.findProduct(it.productId); p.reserved += it.qty; this.ledgerMove("RESERVE",p.id,-it.qty,p.price,o.id,"Allocated to order"); });
        o.reserved = true; o.status = "Ready for Dispensing";
        this.event(o, o.status, "Stock allocated and reserved. Physical stock remains available only to this order.");
        this.saveState(); this.renderAdmin(); this.renderTracking(o); f7.toast("Stock allocated",1300);
    }
    dispenseOrder(id) {
        if (!this.can("dispense")) { f7.toast("Fulfillment requires the Fulfillment & Dispensing Officer role.",2200); return; }
        const o=this.findOrder(id); if(!o || o.status!=="Ready for Dispensing") return;
        o.status="Ready for Dispatch";
        this.event(o,o.status,"Order picked, checked and dispensed. Ready for Dispatch & Delivery.");
        this.saveState(); this.renderAdmin(); this.renderTracking(o); f7.toast("Order marked ready for dispatch",1300);
    }
    dispatchOrder(raw) {
        if (!this.can("dispatch")) { f7.toast("Dispatch requires the Dispatch & Delivery Officer role.",2200); return; }
        let data; try { data=JSON.parse(raw); } catch(e) { data={id:raw,driverId:""}; }
        const o=this.findOrder(data.id); if(!o || o.status!=="Ready for Dispatch") return;
        const drivers=this.users.filter(u=>u.active && u.role==="dispatch_delivery");
        const driverId=data.driverId || this.user().id;
        if (!drivers.some(u=>u.id===driverId)) throw new Error("Choose an active Dispatch & Delivery Officer.");
        o.items.forEach(it=>{const p=this.findProduct(it.productId); if(!p || p.reserved<it.qty || p.stock<it.qty) throw new Error("Inventory balance check failed. Dispatch stopped.");});
        o.items.forEach(it=>{const p=this.findProduct(it.productId); p.reserved -= it.qty; this.ledgerMove("RELEASE",p.id,it.qty,p.price,o.id,"Reservation closed at dispatch"); p.stock -= it.qty; this.ledgerMove("ISSUE",p.id,-it.qty,p.price,o.id,"Issued at dispatch");});
        o.reserved=false; o.issued=true; o.dispatched=true; o.driverId=driverId; o.status="Dispatched";
        const driver=this.users.find(u=>u.id===driverId);
        this.event(o,o.status,`Order dispatched to ${driver.name}. Inventory issued exactly to order quantities.`);
        this.saveState(); this.renderAdmin(); this.renderTracking(o); f7.toast("Order dispatched",1500);
    }
    deliverOrder(raw) {
        let data; try { data=JSON.parse(raw); } catch(e) { data={id:raw,signature:""}; }
        const o=this.findOrder(data.id); if(!o || o.status!=="Dispatched") return;
        const isAdmin=this.role()==="system_admin";
        if(!isAdmin && !(this.role()==="dispatch_delivery" && o.driverId===this.user().id)) { f7.toast("Only the assigned delivery officer or administrator can confirm delivery.",2200); return; }
        const signature=String(data.signature||"").trim(); if(signature.length<2) throw new Error("Customer signature / name is required for delivery confirmation.");
        o.signature=signature; o.delivered=true; o.status="Delivered";
        this.event(o,o.status,`Delivery confirmed by ${this.currentUserName()}; customer signature recorded as “${signature}”.`);
        this.saveState(); this.renderOrders(); this.renderAdmin(); this.renderTracking(o); f7.toast("Delivery verified",1600);
    }
    cancelOrder(id) {
        const o=this.findOrder(id); if(!o) return;
        if(["Dispatched","Delivered"].includes(o.status)) { f7.toast("This order can no longer be cancelled.",1700); return; }
        if(o.reserved){ o.items.forEach(it=>{const p=this.findProduct(it.productId); if(p){p.reserved-=it.qty;this.ledgerMove("RELEASE",p.id,it.qty,p.price,o.id,"Reservation released on cancellation");}}); o.reserved=false; }
        o.status="Cancelled";
        if(o.payment.status==="Verified") o.payment.status="Demo Refund Pending";
        this.event(o,o.status,"Order cancelled before dispatch. Any stock reservation was released back to available inventory.");
        this.saveState(); this.renderAdmin(); this.renderOrders(); this.renderTracking(o);
    }
    restock(raw) {
        if (!this.hasRole("system_admin","inventory_control")) { f7.toast("Only Inventory Control can restock in this demo.",1700); return; }
        let data; try{data=JSON.parse(raw);}catch(e){data={id:raw,qty:0};}
        const p=this.findProduct(Number(data.id)); const qty=Number(data.qty); if(!p || qty<1) throw new Error("Enter a positive restock quantity.");
        p.stock += qty; this.ledgerMove("RESTOCK",p.id,qty,p.price,"","Inventory restock"); this.saveState(); this.renderAdmin(); this.renderAudit(); f7.toast(`${p.name}: +${qty} stock`,1300);
    }
    renderOrders() {
        const list=this.userOrders().slice().reverse();
        this.html("#pq-orders-list", list.length ? list.map(o => `<div class="pq-order-card"><div class="pq-order-head"><div><strong>${this.esc(o.id)}</strong><small>${this.dateTime(o.createdAt)} • ${this.esc(o.trackingCode)}</small></div><span class="pq-status ${o.status.toLowerCase().includes('cancel') ? 'danger' : ''}">${this.esc(o.status)}</span></div><div class="pq-order-meta"><i class="icon f7-icons">person</i><span>${this.esc(o.customer.name)} • ${this.esc(o.customer.phone)}</span></div><p>${o.items.map(i=>`${this.esc(i.name)} × ${i.qty}`).join(", ")}</p><div class="pq-order-total"><span>Total</span><b>${this.money(o.total)}</b></div><div class="pq-order-actions"><a href="/tracking/${o.id}/" class="button button-outline">Track order</a></div></div>`).join("") : `<div class="pq-empty"><i class="icon f7-icons">list_bullet</i><strong>No orders yet</strong><span>Your completed checkouts will appear here.</span><a href="/home" class="button button-fill">Shop now</a></div>`);
    }
    openTracking(id){ this.go(`/tracking/${id}/`); }
    renderTracking(o) {
        if (!o) { this.html("#pq-tracking-body", `<div class="pq-empty"><strong>Order not found</strong></div>`); return; }
        const status = o.status;
        const progress = status === "Payment Rejected / Order Cancelled" || status === "Cancelled" ? -1 : ({
            "Awaiting Payment Verification": 0,
            "Clinical Verification Required": 1,
            "Awaiting Stock Allocation": 2,
            "Ready for Dispensing": 3,
            "Ready for Dispatch": 4,
            "Dispatched": 5,
            "Delivered": 6
        }[status] ?? 0);
        const points = [[12,72],[28,61],[43,67],[55,47],[67,40],[77,27],[89,17]];
        const driverIndex = status === "Delivered" ? 6 : status === "Dispatched" ? 5 : Math.min(Math.max(progress, 0), 4);
        const driver = { x: points[driverIndex][0], y: points[driverIndex][1] };
        const eta = status === "Delivered" ? "Delivered" : status === "Dispatched" ? "Estimated arrival: 20–35 min" : status === "Ready for Dispatch" ? "Awaiting dispatch" : "Processing order";
        const active = progress < 0 ? 0 : Math.min(progress + 1, 6);
        const steps = ["Payment verification","Clinical verification","Stock allocation","Dispensing","Dispatch","Delivery"];
        const lineDots = points.slice(0, Math.min(active + 1, points.length)).map(p=>`<circle cx="${p[0]}" cy="${p[1]}" r="2.1" class="pq-map-stop-dot"></circle>`).join("");
        this.html("#pq-tracking-body", `<div class="pq-track-summary"><div><span>Order</span><strong>${this.esc(o.id)}</strong></div><div><span>Tracking</span><strong>${this.esc(o.trackingCode)}</strong></div><div><span>Total</span><strong>${this.money(o.total)}</strong></div></div>
        <div class="pq-map-card">
          <div class="pq-map-toolbar"><div><strong>Track delivery</strong><small>${this.esc(eta)}</small></div><div class="pq-map-tools"><button class="button button-small pq-map-control" data-map-action="zoom-out" aria-label="Zoom out">−</button><button class="button button-small pq-map-control" data-map-action="zoom-in" aria-label="Zoom in">+</button><button class="button button-small pq-map-control" data-map-action="recenter" aria-label="Recenter"><i class="icon f7-icons">scope</i></button><button class="button button-small pq-map-control" data-map-action="play" aria-label="Play delivery simulation"><i class="icon f7-icons">play_fill</i></button></div></div>
          <div class="pq-map" data-map-order="${this.esc(o.id)}" data-map-step="${driverIndex}">
            <div class="pq-map-canvas">
              <div class="pq-map-road r1"></div><div class="pq-map-road r2"></div><div class="pq-map-road r3"></div><div class="pq-map-road r4"></div><div class="pq-map-road r5"></div>
              <div class="pq-map-water"></div>
              <svg viewBox="0 0 100 100" preserveAspectRatio="none" class="pq-map-route" aria-hidden="true">
                <path d="M12 72 C21 66, 24 55, 32 60 S42 74, 48 63 S56 44, 67 40 S75 29, 89 17" class="pq-route-bg"></path>
                <path d="M12 72 C21 66, 24 55, 32 60 S42 74, 48 63 S56 44, 67 40 S75 29, 89 17" class="pq-route-fg"></path>
                ${lineDots}
              </svg>
              <div class="pq-map-pin pharmacy" style="left:12%;top:72%"><i class="icon f7-icons">building_2_fill</i><span>Pharmacy</span></div>
              <div class="pq-map-pin customer" style="left:89%;top:17%"><i class="icon f7-icons">person_fill</i><span>Customer</span></div>
              <div class="pq-map-driver" style="left:${driver.x}%;top:${driver.y}%"><span class="pq-driver-ring"><i class="icon f7-icons">car_fill</i></span><small class="pq-driver-label">${status === "Delivered" ? "Delivered" : status === "Dispatched" ? "Delivery officer" : "Processing"}</small></div>
            </div>
            <button class="pq-map-compass pq-map-control" data-map-action="recenter" aria-label="Recenter map"><i class="icon f7-icons">location_north_fill</i></button>
            <div class="pq-map-legend"><span><i class="pq-legend-pharmacy"></i>Pharmacy</span><span><i class="pq-legend-route"></i>Route</span><span><i class="pq-legend-driver"></i>Delivery</span></div>
            <div class="pq-map-help">Drag to explore · use + / − to zoom</div>
          </div>
          <div class="pq-map-info"><div><i class="icon f7-icons">location_fill</i><div><strong>${this.esc(o.customer.address)}</strong><small>${this.esc(eta)}</small></div></div></div>
        </div>
        <div class="pq-progress-card"><div class="pq-progress-grid">${steps.map((s,i)=>`<div class="pq-progress-step ${progress>=i+1 || (i===0&&progress>=0) ? 'done':''} ${progress===i+1?'current':''}"><span>${i+1}</span><small>${s}</small></div>`).join("")}</div><div class="pq-current-status">${this.esc(o.status)}</div></div>
        <div class="pq-workflow-feed"><div class="pq-section-head no-top"><strong>Department feed</strong><span>Chain of custody</span></div>${(o.events||[]).slice().reverse().map(e=>`<div class="pq-feed"><div class="pq-feed-dot"></div><div><strong>${this.esc(e.detail)}</strong><small>${this.esc(e.role)} • ${this.esc(e.department)} • ${this.dateTime(e.at)}</small></div></div>`).join("")}</div>
        ${o.dispatched && !o.delivered ? `<div class="pq-delivery-card"><div class="pq-delivery-head"><div><span class="pq-mini-label">Delivery verification</span><h3>Confirm handover</h3></div><span class="pq-role-chip">${this.esc(ROLE.dispatch_delivery)}</span></div><p>Assigned delivery officer: <b>${this.esc((this.users.find(u=>u.id===o.driverId)||{}).name||"Unassigned")}</b></p><input class="pq-input" id="pq-signature" placeholder="Customer signature / name" autocomplete="name"><button class="button button-fill" onclick="f7Func('deliver',JSON.stringify({id:'${this.esc(o.id)}',signature:document.getElementById('pq-signature').value}))">Confirm signed delivery</button></div>` : o.delivered ? `<div class="pq-success-strip large"><i class="icon f7-icons">checkmark_seal_fill</i><span>Delivered. Customer signature: <b>${this.esc(o.signature)}</b></span></div>` : ""}`);
        const routeFraction = Math.max(0, Math.min(1, 1 - (Math.min(progress + 1, 6) / 6)));
        this.exec(`var r=document.querySelector('.pq-route-fg');if(r){var len=r.getTotalLength();r.style.strokeDasharray=len;r.style.strokeDashoffset=len*${routeFraction};}`);
    }

    handleMap(raw) {
        return raw;
    }
    renderFavorites(){
        const list=this.favorites.map(id=>this.findProduct(id)).filter(Boolean);
        this.html("#pq-favorites-list", list.length ? list.map(p=>`<div class="pq-favorite-row"><div class="pq-mini-icon">${p.requiresRx?"Rx":"OTC"}</div><div><strong>${this.esc(p.name)}</strong><small>${this.money(p.price)} • ${this.esc(p.category)}</small></div><a href="/product/${p.id}/" class="button button-outline">View</a></div>`).join("") : `<div class="pq-empty"><i class="icon f7-icons">heart</i><strong>No favorites yet</strong><span>Tap the heart on a product to save it.</span></div>`);
    }
    renderAuth(){
        const u=this.user();
        this.html("#pq-auth-user", `<div class="pq-user-summary"><div class="pq-avatar">${this.esc(u.name.slice(0,1))}</div><div><strong>${this.esc(u.name)}</strong><small>${this.esc(ROLE[u.role]||u.role)} • ${this.esc(u.email)}</small></div></div>`);
    }
    login(raw){
        let d; try{d=JSON.parse(raw);}catch(e){throw new Error("Sign-in data could not be read.");}
        const u=this.users.find(x=>x.email.toLowerCase()===String(d.email||"").trim().toLowerCase() && x.password===String(d.password||""));
        if(!u || !u.active) throw new Error("Invalid demo sign-in details.");
        this.currentUserId=u.id; this.adminUnlocked=u.role==="system_admin"; this.saveState(); this.renderAuth(); this.renderAccount(); this.renderAdmin();
        f7.toast(`Signed in as ${ROLE[u.role]}`,1500); this.go("/home");
    }
    demoLogin(email){ const u=this.users.find(x=>x.email===email); if(!u)return; this.currentUserId=u.id; this.adminUnlocked=u.role==="system_admin"; this.saveState(); f7.toast(`Demo sign-in: ${ROLE[u.role]}`,1500); this.go("/home"); }
    signup(raw){
        let d; try{d=JSON.parse(raw);}catch(e){throw new Error("Registration data could not be read.");}
        if(!d.name || !d.email || !d.password) throw new Error("Name, email and password are required.");
        if(this.users.some(u=>u.email.toLowerCase()===String(d.email).toLowerCase())) throw new Error("An account with that email already exists.");
        const u={id:"u-"+(++this.sequence),name:String(d.name),email:String(d.email).toLowerCase(),phone:String(d.phone||""),password:String(d.password),role:"customer",active:true};
        this.users.push(u);this.currentUserId=u.id;this.saveState();f7.toast("Demo account created",1500);this.go("/home");
    }
    logout(){this.currentUserId="u-customer";this.adminUnlocked=false;this.saveState();f7.toast("Signed out",1100);this.go("/home");}
    renderAccount(){ const u=this.user(); this.html("#pq-account-card",`<div class="pq-account-card"><div class="pq-avatar big">${this.esc(u.name.slice(0,1))}</div><h2>${this.esc(u.name)}</h2><p>${this.esc(u.email)}<br>${this.esc(u.phone||"No phone")}</p><span class="pq-role-chip">${this.esc(ROLE[u.role]||u.role)}</span><div class="pq-account-stats"><div><b>${this.userOrders().length}</b><small>Orders</small></div><div><b>${this.favorites.length}</b><small>Favorites</small></div><div><b>${this.prescriptions.filter(r=>r.customerId===u.id).length}</b><small>RX records</small></div></div><div class="pq-account-actions"><a href="/auth" class="button button-outline">Sign in / switch demo user</a><button class="button button-fill" onclick="f7Func('logout','1')">Sign out</button></div></div>`); }
    setSetting(raw){ let d;try{d=JSON.parse(raw);}catch(e){return;} if(d.name==="theme") this.settings.theme=d.value?"dark":"light"; else if(d.name in this.settings) this.settings[d.name]=!!d.value; this.saveState();this.applySettings();this.renderSettings();f7.toast("Setting updated",900); }
    renderSettings(){
        const onTheme=this.settings.theme==="dark";
        this.exec(`document.getElementById('setting-theme').checked=${onTheme};document.getElementById('setting-notifications').checked=${!!this.settings.notifications};document.getElementById('setting-compact').checked=${!!this.settings.compact};`);
    }
    adminPin(raw){
        const pin=String(raw||""); if(pin!==ADMIN_PIN){f7.alert("Incorrect demo administrator PIN.","Administrator");return;} this.adminUnlocked=true;this.renderAdmin();f7.toast("Administrator controls unlocked",1200);
    }
    renderAdmin(){
        if(!this.adminUnlocked && this.role()!=="system_admin"){
            this.html("#pq-admin-body",`<div class="pq-admin-lock"><i class="icon f7-icons">lock_shield_fill</i><h2>Admin controls</h2><p>Administrator access is required for user roles, reconciliation and workflow supervision.</p><input id="pq-admin-pin" class="pq-input center" type="password" inputmode="numeric" maxlength="4" placeholder="Demo PIN: 1234"><button class="button button-fill" onclick="f7Func('adminPin',document.getElementById('pq-admin-pin').value)">Unlock admin</button><small>POC only — this PIN is not secure and will be replaced by backend authentication later.</small></div>`);return; }
        this.adminUnlocked=true;
        const pending=this.orders.filter(o=>o.status==="Awaiting Payment Verification").length;
        const clinical=this.orders.filter(o=>o.status==="Clinical Verification Required").length;
        const allocation=this.orders.filter(o=>o.status==="Awaiting Stock Allocation").length;
        const dispatch=this.orders.filter(o=>o.status==="Ready for Dispatch").length;
        const delivered=this.orders.filter(o=>o.status==="Delivered").length;
        const audit=this.runAudit(false);
        this.html("#pq-admin-body",`<div class="pq-admin-metrics"><div><b>${pending}</b><span>Payment</span></div><div><b>${clinical}</b><span>Clinical</span></div><div><b>${allocation}</b><span>Allocation</span></div><div><b>${dispatch}</b><span>Dispatch</span></div><div><b>${delivered}</b><span>Delivered</span></div><div><b>${this.money(this.orders.filter(o=>o.status!=="Cancelled"&&o.status!=="Payment Rejected / Order Cancelled").reduce((s,o)=>s+o.total,0))}</b><span>Order value</span></div></div><div class="pq-audit-banner ${audit.ok?'ok':'bad'}"><i class="icon f7-icons">${audit.ok?'checkmark_shield_fill':'exclamationmark_triangle_fill'}</i><div><strong>${audit.ok?'Reconciliation balanced':'Review reconciliation exceptions'}</strong><small>${audit.summary}</small></div><a href="/audit" class="button button-small button-outline">Audit</a></div><div class="pq-section-head"><strong>Workflow supervisor</strong><span>${this.esc(ROLE[this.role()]||this.role())}</span></div>${this.orders.slice().reverse().map(o=>this.adminOrderCard(o)).join("") || `<div class="pq-empty mini"><span>No orders yet.</span></div>`}<div class="pq-section-head"><strong>User roles</strong><span>Assign duty</span></div>${this.users.map(u=>`<div class="pq-user-row"><div><strong>${this.esc(u.name)}</strong><small>${this.esc(u.email)} • ${this.esc(ROLE[u.role]||u.role)}</small></div><select onchange="f7Func('assignRole',JSON.stringify({id:'${this.esc(u.id)}',role:this.value}))" ${this.role()!=="system_admin"?'disabled':''}>${Object.keys(ROLE).map(r=>`<option value="${r}" ${u.role===r?'selected':''}>${this.esc(ROLE[r])}</option>`).join("")}</select><button class="button button-small ${u.active?'button-outline':'button-fill'}" onclick="f7Func('toggleUser','${this.esc(u.id)}')">${u.active?'Active':'Disabled'}</button></div>`).join("")}<div class="pq-section-head"><strong>Inventory control</strong><span>Physical / available / reserved</span></div>${this.inventory.map(p=>`<div class="pq-inventory-row"><div><strong>${this.esc(p.name)}</strong><small>${this.esc(p.sku)} • Physical ${p.stock} • Reserved ${p.reserved} • Available ${this.available(p)}</small></div><div class="pq-stock-price">${this.money(p.price)}</div><button class="button button-small button-outline" onclick="f7.prompt('Restock quantity','Inventory',function(q){if(q)f7Func('restock',JSON.stringify({id:${p.id},qty:Number(q)}));},function(){},'10')">Restock</button></div>`).join("")}`);
    }
    adminOrderCard(o){
        let action="";
        if(o.status==="Awaiting Payment Verification" && this.can("payment")) action=`<button class="button button-small button-fill" onclick="f7Func('verifyPayment','${o.id}')">Verify payment</button><button class="button button-small button-outline color-red" onclick="f7Func('rejectPayment','${o.id}')">Reject</button>`;
        else if(o.status==="Clinical Verification Required" && this.can("clinical")) action=`<button class="button button-small button-fill" onclick="f7Func('verifyRx','${o.id}')">Verify prescription</button>`;
        else if(o.status==="Awaiting Stock Allocation" && this.can("allocate")) action=`<button class="button button-small button-fill" onclick="f7Func('allocate','${o.id}')">Allocate stock</button>`;
        else if(o.status==="Ready for Dispensing" && this.can("dispense")) action=`<button class="button button-small button-fill" onclick="f7Func('dispense','${o.id}')">Mark dispensed</button>`;
        else if(o.status==="Ready for Dispatch" && this.can("dispatch")) { const drivers=this.users.filter(u=>u.active&&u.role==="dispatch_delivery"); action=`<select id="driver-${o.id}" class="pq-inline-select">${drivers.map(d=>`<option value="${d.id}">${this.esc(d.name)}</option>`).join("")}</select><button class="button button-small button-fill" onclick="f7Func('dispatch',JSON.stringify({id:'${o.id}',driverId:document.getElementById('driver-${o.id}').value}))">Dispatch</button>`; }
        else if(o.status==="Dispatched") action=`<a href="/tracking/${o.id}/" class="button button-small button-outline">Delivery</a>`;
        else if(!["Delivered","Cancelled","Payment Rejected / Order Cancelled"].includes(o.status)) action=`<span class="pq-muted-action">Next duty: ${this.esc(this.nextRole(o.status))}</span>`;
        const cancelable=!['Dispatched','Delivered','Cancelled','Payment Rejected / Order Cancelled'].includes(o.status);
        if(cancelable) action+=`<button class="button button-small button-outline color-red" onclick="f7Func('cancelOrder','${o.id}')">Cancel</button>`;
        return `<div class="pq-order-card admin"><div class="pq-order-head"><div><strong>${this.esc(o.id)}</strong><small>${this.esc(o.customer.name)} • ${this.money(o.total)}</small></div><span class="pq-status">${this.esc(o.status)}</span></div><p>${o.items.map(i=>`${this.esc(i.name)} × ${i.qty}`).join(', ')}</p><div class="pq-order-actions">${action}<a href="/tracking/${o.id}/" class="button button-small button-outline">Track</a></div></div>`;
    }
    nextRole(status){return ({"Awaiting Payment Verification":"Cashier / Payment Verification Officer","Clinical Verification Required":"Pharmacist / Clinical Verification Officer","Awaiting Stock Allocation":"Inventory Control Officer","Ready for Dispensing":"Fulfillment & Dispensing Officer","Ready for Dispatch":"Dispatch & Delivery Officer","Dispatched":"Assigned delivery officer"}[status]||"Completed");}
    assignRole(raw){if(this.role()!=="system_admin"){f7.toast("Only the System Administrator can assign roles.",1700);return;}let d;try{d=JSON.parse(raw);}catch(e){return;}const u=this.users.find(x=>x.id===d.id);if(!u||!ROLE[d.role])return;if(u.id===this.user().id&&d.role!=="system_admin"){f7.toast("Administrator cannot remove their own administrator role in this demo.",1800);return;}u.role=d.role;if(u.id===this.currentUserId)this.adminUnlocked=d.role==="system_admin";this.saveState();this.renderAdmin();f7.toast(`${u.name}: role updated`,1300);}
    toggleUser(id){if(this.role()!=="system_admin"){f7.toast("Only the System Administrator can manage users.",1700);return;}const u=this.users.find(x=>x.id===id);if(!u)return;if(u.id===this.user().id){f7.toast("You cannot disable the current administrator session.",1700);return;}u.active=!u.active;this.saveState();this.renderAdmin();}
    runAudit(record){
        const issues=[];
        const inventoryRows=this.inventory.map(p=>{
            const opening=this.ledger.filter(m=>m.productId===p.id&&m.type==="OPENING").reduce((s,m)=>s+Math.abs(Number(m.qty||0)),0);
            const restock=this.ledger.filter(m=>m.productId===p.id&&m.type==="RESTOCK").reduce((s,m)=>s+Math.abs(Number(m.qty||0)),0);
            const issued=this.ledger.filter(m=>m.productId===p.id&&m.type==="ISSUE").reduce((s,m)=>s+Math.abs(Number(m.qty||0)),0);
            const expectedPhysical=opening+restock-issued;
            const available=this.available(p);
            const expectedAvailable=expectedPhysical-Number(p.reserved||0);
            const ok=expectedPhysical===Number(p.stock||0)&&expectedAvailable===available&&p.stock>=0&&p.reserved>=0;
            if(!ok) issues.push(`${p.sku}: inventory quantity mismatch`);
            return {p,opening,restock,issued,expectedPhysical,available,expectedAvailable,ok};
        });
        const orderRows=this.orders.map(o=>{
            const lines=o.items.reduce((s,i)=>s+(Number(i.qty)||0)*(Number(i.unitPrice)||0),0);
            const paymentMatch=o.payment&&o.payment.status==="Verified" ? Number(o.payment.amount)===Number(o.total) : true;
            const totalOk=lines===Number(o.productTotal)&&lines+Number(o.deliveryFee)===Number(o.total)&&paymentMatch;
            if(!totalOk) issues.push(`${o.id}: order value or payment mismatch`);
            const issueQty=o.items.reduce((s,i)=>s+Number(i.qty||0),0);
            const issuedLedger=this.ledger.filter(m=>m.orderId===o.id&&m.type==="ISSUE").reduce((s,m)=>s+Math.abs(Number(m.qty||0)),0);
            if(o.issued&&issuedLedger!==issueQty) issues.push(`${o.id}: issued quantity mismatch`);
            return {o,lines,paymentMatch,totalOk,issueQty,issuedLedger};
        });
        const sales=this.orders.filter(o=>!['Cancelled','Payment Rejected / Order Cancelled'].includes(o.status)).reduce((s,o)=>s+Number(o.total||0),0);
        const verifiedPayments=this.orders.filter(o=>o.payment&&o.payment.status==="Verified").reduce((s,o)=>s+Number(o.payment.amount||0),0);
        const report={at:new Date().toISOString(),ok:issues.length===0,issues,orders:this.orders.length,sales,verifiedPayments,summary:issues.length===0?`All ${this.inventory.length} SKU records and ${this.orders.length} orders reconcile.`:`${issues.length} control exception(s) found. Review the affected rows.` ,inventoryRows,orderRows};
        if(record){const history={at:report.at,ok:report.ok,issues:report.issues,orders:report.orders,sales:report.sales,verifiedPayments:report.verifiedPayments,summary:report.summary};this.auditRuns.push(history);this.auditRuns=this.auditRuns.slice(-20);this.saveState();}
        return report;
    }
    renderAudit(){
        const a=this.runAudit(false);
        const moneyN=(n)=>this.money(n);
        const invRows=a.inventoryRows.map(r=>`<tr class="${r.ok?'':'is-exception'}"><td>${this.esc(r.p.sku)}</td><td>${this.esc(r.p.name)}</td><td>${r.opening}</td><td>${r.restock}</td><td>${r.issued}</td><td>${r.p.stock}</td><td>${r.p.reserved}</td><td>${r.available}</td><td>${r.expectedPhysical}</td><td>${r.ok?'<span class="pq-audit-ok">Balanced</span>':'<span class="pq-audit-bad">Exception</span>'}</td></tr>`).join("");
        const orderRows=a.orderRows.slice().reverse().map(r=>`<tr class="${r.totalOk?'':'is-exception'}"><td>${this.esc(r.o.id)}</td><td>${r.o.items.reduce((s,i)=>s+Number(i.qty||0),0)}</td><td>${moneyN(r.lines)}</td><td>${moneyN(r.o.deliveryFee)}</td><td>${moneyN(r.o.total)}</td><td>${this.esc(r.o.payment?.method||'')}</td><td>${this.esc(r.o.payment?.status||'')}</td><td>${r.totalOk?'<span class="pq-audit-ok">Balanced</span>':'<span class="pq-audit-bad">Exception</span>'}</td></tr>`).join("");
        const ledgerRows=this.ledger.slice().reverse().slice(0,120).map(m=>{const p=this.findProduct(m.productId);const qty=m.type==="ISSUE"?-Math.abs(Number(m.qty||0)):Number(m.qty||0);const amount=Math.abs(qty)*Number(m.unitPrice||0);return `<tr><td>${this.dateTime(m.at)}</td><td>${this.esc(m.type)}</td><td>${this.esc(m.orderId||'—')}</td><td>${this.esc(p?p.sku:'—')}</td><td>${qty>0?'+':''}${qty}</td><td>${moneyN(m.unitPrice)}</td><td>${moneyN(amount)}</td><td>${this.esc(m.actor)}</td><td>${this.esc(m.role)}</td></tr>`}).join("");
        const exceptionRows=a.issues.length?a.issues.map(x=>`<tr><td class="pq-audit-bad">Exception</td><td colspan="5">${this.esc(x)}</td></tr>`).join(""):`<tr><td class="pq-audit-ok">OK</td><td colspan="5">No quantity, price or payment discrepancy detected.</td></tr>`;
        const history=this.auditRuns.slice().reverse().map(r=>`<tr><td>${this.dateTime(r.at)}</td><td>${r.orders}</td><td>${moneyN(r.sales)}</td><td>${moneyN(r.verifiedPayments)}</td><td>${r.ok?'<span class="pq-audit-ok">Balanced</span>':'<span class="pq-audit-bad">Review</span>'}</td></tr>`).join("")||`<tr><td colspan="5">No prior audit runs.</td></tr>`;
        const banner=`<div class="pq-audit-banner ${a.ok?'ok':'bad'} large"><i class="icon f7-icons">${a.ok?'checkmark_shield_fill':'exclamationmark_triangle_fill'}</i><div><strong>${a.ok?'All controls balanced':'Reconciliation requires attention'}</strong><small>${this.esc(a.summary)}</small></div><button class="button button-small button-outline" onclick="f7Func('audit','1')">Run audit</button></div>`;
        const metrics=`<div class="pq-audit-metrics"><div><b>${this.orders.length}</b><span>Orders</span></div><div><b>${this.inventory.length}</b><span>SKUs</span></div><div><b>${moneyN(a.sales)}</b><span>Order value</span></div><div><b>${moneyN(a.verifiedPayments)}</b><span>Verified payments</span></div></div>`;
        const invTable=`<div class="pq-section-head"><strong>Inventory reconciliation</strong><span>Quantity control</span></div><div class="pq-audit-table-wrap"><table class="pq-audit-table"><thead><tr><th>SKU</th><th>Product</th><th>Opening</th><th>Restock</th><th>Issued</th><th>Physical</th><th>Reserved</th><th>Available</th><th>Expected</th><th>Check</th></tr></thead><tbody>${invRows}</tbody></table></div>`;
        const orderTable=`<div class="pq-section-head"><strong>Order & payment reconciliation</strong><span>Sales control</span></div><div class="pq-audit-table-wrap"><table class="pq-audit-table"><thead><tr><th>Order</th><th>Qty</th><th>Products</th><th>Delivery</th><th>Total</th><th>Method</th><th>Payment</th><th>Check</th></tr></thead><tbody>${orderRows||'<tr><td colspan="8">No orders recorded.</td></tr>'}</tbody></table></div>`;
        const exceptionTable=`<div class="pq-section-head"><strong>Exceptions</strong><span>${a.issues.length}</span></div><div class="pq-audit-table-wrap"><table class="pq-audit-table"><thead><tr><th>Status</th><th colspan="5">Control observation</th></tr></thead><tbody>${exceptionRows}</tbody></table></div>`;
        const ledgerTable=`<div class="pq-section-head"><strong>Stock movement register</strong><span>Latest 120 entries</span></div><div class="pq-audit-table-wrap"><table class="pq-audit-table"><thead><tr><th>Date</th><th>Movement</th><th>Reference</th><th>SKU</th><th>Qty</th><th>Unit</th><th>Value</th><th>Actor</th><th>Role</th></tr></thead><tbody>${ledgerRows||'<tr><td colspan="9">No movements recorded.</td></tr>'}</tbody></table></div>`;
        const historyTable=`<div class="pq-section-head"><strong>Audit history</strong><span>Last ${this.auditRuns.length}</span></div><div class="pq-audit-table-wrap"><table class="pq-audit-table"><thead><tr><th>Date</th><th>Orders</th><th>Order value</th><th>Verified payments</th><th>Result</th></tr></thead><tbody>${history}</tbody></table></div>`;
        this.html("#pq-audit-body",banner+metrics+invTable+orderTable+exceptionTable+ledgerTable+historyTable);
    }
    confirmResetData(){
        f7.confirm("This will remove demo orders, prescriptions, cart, favorites and inventory movements and restore opening stock. Continue?", "Reset POC data", () => {
            this.cart=[];this.orders=[];this.prescriptions=[];this.favorites=[];this.recent=[];this.ledger=[];this.auditRuns=[];
            this.inventory.forEach(p=>{p.stock=p.openingStock;p.reserved=0;});
            this.seedOpeningLedger();this.saveState();this.renderProducts();this.renderOrders();this.renderAdmin();this.renderAudit();this.updateBadges();f7.toast("POC data reset",1400);
        });
    }
    support(){ f7.confirm("Demo pharmacy support: 0800-PHARMA (demo only). No real call is placed.","PharmaQuick Support",()=>{}); }
    confirmExit(){ f7.confirm("Are you sure you want to exit PharmaQuick?","Exit PharmaQuick",()=>app.Exit()); }
}

new App();
